package com.example

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.projectbp_2706.R

class loginactyvity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_loginactyvity)
    }
}